<div class="inline-flex items-center gap-x-2">
    <span class="w-2 h-2 bg-white inline-block"> </span>

    <h3 class="font-bold text-lg"> <?php echo e($slot); ?> </h3>
</div>
<?php /**PATH C:\lara\pixel-positions\resources\views/components/section-heading.blade.php ENDPATH**/ ?>
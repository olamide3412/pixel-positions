<h1 class="font-bold text-center text-4xl mb-8"> <?php echo e($slot); ?> </h1>
<?php /**PATH C:\lara\pixel-positions\resources\views/components/page-heading.blade.php ENDPATH**/ ?>
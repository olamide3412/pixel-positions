<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Pixel Position</title>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hanken+Grotesk:wght@400;500;600&display=swap" rel="stylesheet">


<?php if(app()->environment('production')): ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/app-Dpu_IQnt.css')); ?>">
    <script src="<?php echo e(asset('build/app-C1-XIpUa.js')); ?>" defer></script>
<?php else: ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php endif; ?>





</head>
<body class="bg-black text-white font-hanken-grotesk pb-20">

    <div class="">


        <nav class="flex justify-between items-center  py-4 border-b border-white/10 p-3 ">
            <div>
                <a href="/">
                    <img src="<?php echo e(Vite::asset('resources/images/logo.svg')); ?>" alt="">
                </a>
            </div>

            <div class="space-x-6 font-bold">
                <a href="#">Jobs</a>
                <a href="#">Careers</a>
                <a href="#">Salaries</a>
                <a href="#">Companies</a>
            </div>

            <?php if(auth()->guard()->check()): ?>
                <div class="space-x-6 font-bold flex">
                    <a href="/jobs/create">Post a Job</a>

                    <form method="POST" action="/logout">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button>Log Out</button>
                    </form>
                </div>
            <?php endif; ?>



        </nav>





        <main  class="mt-10 max-w-[986px] mx-auto px-5 pt-106">
            <?php if(auth()->guard()->guest()): ?>
            <div class="flex justify-center font-bold space-x-2">
                <a href="/register" class="btn text-primary ml-2 border-primary md:border-2 hover:bg-primary hover:text-white transition ease-out duration-500">Sign Up</a>
                <a href="/login"  class="btn text-primary border-primary md:border-2 hover:bg-primary hover:text-white transition ease-out duration-500" >Log In</a>
            </div>
            <?php endif; ?>

            <?php echo e($slot); ?>

        </main>

    </div>





</body>
</html>
<?php /**PATH C:\lara\pixel-positions\resources\views/components/layout.blade.php ENDPATH**/ ?>